GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007

[Full GPL-3.0 license text from: https://www.gnu.org/licenses/gpl-3.0.txt]